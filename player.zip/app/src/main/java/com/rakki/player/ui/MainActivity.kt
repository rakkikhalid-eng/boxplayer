package com.rakki.player.ui

import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rakki.player.R
import com.rakki.player.box.BoxConnector
import com.rakki.player.proxy.StreamProxyServer

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var edtUrl: EditText
    private lateinit var edtBoxIp: EditText
    private lateinit var btnCast: Button
    private var proxyServer: StreamProxyServer? = null
    private var lastCapturedUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        edtUrl = findViewById(R.id.edtUrl)
        edtBoxIp = findViewById(R.id.edtBoxIp)
        btnCast = findViewById(R.id.btnCast)

        try {
            proxyServer = StreamProxyServer(8080)
            proxyServer?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url.toString()
                if (url.contains(".m3u8") || url.contains(".ts") || url.contains("mystream") || url.contains("cinejoy")) {
                    lastCapturedUrl = url
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Captured Stream!", Toast.LENGTH_SHORT).show()
                        btnCast.text = "Cast Stream to TV Box"
                        btnCast.isEnabled = true
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }

        findViewById<Button>(R.id.btnGo).setOnClickListener {
            val url = edtUrl.text.toString()
            if (url.isNotEmpty()) {
                webView.loadUrl(if (url.startsWith("http")) url else "https://www.google.com/search?q=$url")
            }
        }

        btnCast.setOnClickListener {
            val boxIp = edtBoxIp.text.toString().trim()
            if (boxIp.isEmpty()) {
                Toast.makeText(this, "Please enter TV Box IP", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (lastCapturedUrl.isEmpty()) {
                Toast.makeText(this, "No m3u8 stream captured yet!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val localProxyUrl = "http://127.0.0.1:8080/stream?url=" + android.net.Uri.encode(lastCapturedUrl) + "&ua=" + android.net.Uri.encode(webView.settings.userAgentString) + "&ref=" + android.net.Uri.encode(webView.url ?: "")

            BoxConnector.sendStreamToBox(boxIp, localProxyUrl, "Cinejoy / Mystream Video") { success, msg ->
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }

        edtUrl.setText("https://www.google.com")
    }

    override fun onDestroy() {
        super.onDestroy()
        proxyServer?.stop()
    }
}
