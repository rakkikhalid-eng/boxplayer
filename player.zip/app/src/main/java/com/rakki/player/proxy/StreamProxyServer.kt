package com.rakki.player.proxy

import fi.iki.elonen.NanoHTTPD
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStream

class StreamProxyServer(port: Int = 8080) : NanoHTTPD(port) {
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        val parms = session.parms
        val targetUrl = parms["url"] ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "Missing target URL")

        val userAgent = parms["ua"] ?: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        val referer = parms["ref"] ?: ""

        try {
            val reqBuilder = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", userAgent)
            
            if (referer.isNotEmpty()) {
                reqBuilder.header("Referer", referer)
            }

            val response = client.newCall(reqBuilder.build()).execute()
            val body = response.body
            val inputStream: InputStream = body?.byteStream() ?: return newFixedLengthResponse(Response.Status.NO_CONTENT, MIME_PLAINTEXT, "")
            
            val mimeType = response.header("Content-Type", "application/vnd.apple.mpegurl") ?: "video/mp2t"
            
            return newChunkedResponse(Response.Status.LOOKUP, mimeType, inputStream)
        } catch (e: Exception) {
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Proxy Error: ${e.message}")
        }
    }
}
