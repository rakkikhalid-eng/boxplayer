package com.rakki.boxdlna

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Simple programmatic layout or inflated view for stream input
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        val title = android.widget.TextView(this).apply {
            text = "Box DLNA - M3U8 Stream Player"
            textSize = 22f
            setPadding(0, 0, 0, 32)
        }
        layout.addView(title)

        val inputUrl = EditText(this).apply {
            hint = "Enter .m3u8 stream URL (Cinejoy/Flystream)"
            setText("https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8")
            setPadding(24, 24, 24, 24)
        }
        layout.addView(inputUrl)

        val inputUserAgent = EditText(this).apply {
            hint = "User-Agent (Optional)"
            setText("Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            setPadding(24, 24, 24, 24)
        }
        layout.addView(inputUserAgent)

        val inputReferer = EditText(this).apply {
            hint = "Referer (Optional)"
            setPadding(24, 24, 24, 24)
        }
        layout.addView(inputReferer)

        val btnPlay = Button(this).apply {
            text = "Play Stream"
            setOnClickListener {
                val url = inputUrl.text.toString().trim()
                val ua = inputUserAgent.text.toString().trim()
                val ref = inputReferer.text.toString().trim()

                val intent = Intent(this@MainActivity, PlayerActivity::class.java).apply {
                    putExtra("stream_url", url)
                    putExtra("user_agent", ua)
                    putExtra("referer", ref)
                }
                startActivity(intent)
            }
        }
        layout.addView(btnPlay)

        setContentView(layout)
    }
}
