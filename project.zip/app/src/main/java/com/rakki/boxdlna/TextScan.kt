package com.rakki.boxdlna

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.CueGroup
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * Many streams carry their own subtitle track, perfectly in sync with the picture. This hidden, muted, picture-less
 * player plays a window of the movie at 2x and records when that track shows text (100 ms resolution), a timing
 * reference that needs no audio analysis and no speech model. Main thread only; [onDone] gets null when the stream
 * has no usable subtitle track.
 */
class TextScan(
    private val ctx: Context,
    private val item: MediaItem,
    private val startMs: Long,
    private val durMs: Long,
    private val onDone: (FloatArray?) -> Unit
) {
    private var player: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var done = false
    private val t0 = System.currentTimeMillis()
    private val n = (durMs / 100).toInt()
    private val arr = FloatArray(n)
    private var lastBin = 0
    private var cueOn = false
    private var sawText = false

    private val poll = object : Runnable {
        override fun run() {
            if (done) return
            val p = player ?: return
            val bin = ((p.currentPosition - startMs) / 100).toInt()
            if (bin > lastBin) {
                for (i in lastBin until minOf(bin, n)) arr[i] = if (cueOn) 1f else 0f
                lastBin = bin
            }
            val timeout = System.currentTimeMillis() - t0 > 45_000
            when {
                lastBin >= n -> finish(true)
                timeout -> finish(sawText && lastBin >= n / 2)
                else -> h.postDelayed(this, 40)
            }
        }
    }

    fun start() {
        val http = Net.factory(Renderer.uri)
        val p = ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http)))
            .build()
        player = p
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        p.volume = 0f
        p.setPlaybackSpeed(2f)
        p.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                if (sawText) return
                val g = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (g == null) {
                    if (tracks.groups.isNotEmpty()) finish(false)
                    return
                }
                sawText = true
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
                    .build()
            }

            override fun onCues(cueGroup: CueGroup) { cueOn = cueGroup.cues.isNotEmpty() }

            override fun onPlayerError(error: PlaybackException) {
                CmdLog.add("text scan error: " + error.errorCodeName)
                finish(false)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) finish(sawText)
            }
        })
        p.setMediaItem(item, startMs)
        p.prepare()
        p.playWhenReady = true
        h.post(poll)
    }

    private fun release() {
        h.removeCallbacks(poll)
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    private fun finish(ok: Boolean) {
        if (done) return
        done = true
        val used = ok && sawText && arr.count { it > 0f } >= n / 20
        release()
        onDone(if (used) arr else null)
    }

    /** Stops without calling [onDone]. */
    fun cancel() {
        if (done) return
        done = true
        release()
    }
}
